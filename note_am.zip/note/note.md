# `HTML5`新特性 - `Unit05`

# 1.地理位置

地理位置`API`允许用户向`WEB`应用程序提供他们的位置，但出于隐私考虑，报告地理位置前会请求用户许可。

> 从`Google Chrome 50`开始，地理位置`API`只能在`HTTPS`环境下工作

获取地理位置的`API`是：

```javascript

Geolocation navigator.geolocation

Geolocation window.navigator.geolocation

```

> `window`对象是`BOM`的顶层对象，包含的属性有：
>
> `history`，返回`History`对象
>
> `location`，返回`Location`对象
>
> `navigator`，返回`Navigator` 对象 
>
> ​	· `userAgent`属性用来获取用户代理器(浏览器)的相关信息
>
> ​	· `geolocation`属性返回`Geolocation`的对象

# 2.`Geolocation`对象

通过`Geolocation`对象可以进行用户的地理定位。

## · `getCurrentPosition()`方法

`getCurrentPosition()`方法用于获取设备的当前位置，其语法结构是：

```javascript

Geolocation.getCurrentPosition(success[,error[,options]])

```

> `success`参数是指成功获取位置时的回调函数
>
> ​	`success`的回调函数中，使用`GeolocationPosition`对象作为唯一参数
>
> ​	`GeolocationPosition`对象有一个`coords`属性，该属性返回
>
> ​	`GeolocationCoordinates`对象，在该对象中存在`longitude`和	
>
> ​	`latitude`属性，分别代表地理位置的经度和纬度，其语法结构是：
>
> ​	
>
> ```javascript
> 
> let geo = navigator.geolocation;
> geo.getCurrentPoisition((position)=>{
>     //返回GeolocationCooridinates对象(坐标对象)
>    	let coords = position.coords; 
>     //获取经度
>     let longitude = coords.longitude;
>     //获取纬度
>     let latitude = coords.latitude;
> });
> 
> 
> ```
>
> `error`参数是指获取位置失败时的回调函数
>
> `options`参数是指对于当前的方法进行相关的配置

# 3.百度地图`API`

## 3.1 注册百度地图开发者

